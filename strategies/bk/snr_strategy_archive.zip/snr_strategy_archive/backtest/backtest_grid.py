"""
SNR v3 全參數窮舉掃描
- 所有組合跑完存到 backtest_results.csv
- 支援中斷後繼續（已跑過的組合自動跳過）
- 結束後印出 Top 20

用法：
    python backtest_grid.py           # 跑全部
    python backtest_grid.py --top 20  # 只看結果不跑
"""
import asyncio, sys, os, csv, time, itertools, argparse
import numpy as np
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/..")
from backtest.engine import SNRBacktestRunner

# ── 參數網格 ──────────────────────────────────────────────────────────────────
GRID = {
    "fake_break_depth_mult": [0.20, 0.30, 0.40, 0.50],
    "htf_primary_ema":       [20, 50, 100, 200],
    "htf_secondary_ema":     [9, 21, 50],
    "min_rr":                [1.2, 1.5, 1.8],
    "vol_mult":              [0.0, 1.0, 1.5],
    "session":               ["london_ny", "ny_only", "all_day"],
}

FIXED = dict(sl_max_atr_mult=1.5)

RESULT_FILE = Path(__file__).parent / "backtest_results.csv"
CSV_FIELDS  = ["fake_break_depth_mult", "htf_primary_ema", "htf_secondary_ema",
               "min_rr", "vol_mult", "session",
               "n_trades", "win_rate", "pf", "net_pnl", "mdd", "avg_r", "secs"]

# ── 載入已完成的組合（支援中斷後繼續）────────────────────────────────────────
def load_done() -> set:
    done = set()
    if RESULT_FILE.exists():
        with open(RESULT_FILE, newline="") as f:
            for row in csv.DictReader(f):
                key = tuple(row[k] for k in GRID.keys())
                done.add(key)
    return done

def key_of(cfg: dict) -> tuple:
    return tuple(str(cfg[k]) for k in GRID.keys())

# ── 單次回測 ──────────────────────────────────────────────────────────────────
async def run_one(cfg: dict) -> dict:
    params = {**FIXED}
    for k in GRID:
        if k != "session":
            params[k] = cfg[k]

    # 時段設定
    session = cfg["session"]
    if session == "ny_only":
        params["session_london_start"] = 99   # 關閉倫敦盤
        params["session_london_end"]   = 99
        params["session_ny_start"]     = 13
        params["session_ny_start_min"] = 30
        params["session_ny_end"]       = 20
    elif session == "all_day":
        params["session_london_start"] = 0    # 全天
        params["session_london_end"]   = 24
        params["session_ny_start"]     = 99   # 不需要 NY 另設
        params["session_ny_start_min"] = 0
        params["session_ny_end"]       = 99
    else:  # london_ny
        params["session_london_start"] = 7
        params["session_london_end"]   = 12
        params["session_ny_start"]     = 13
        params["session_ny_start_min"] = 30
        params["session_ny_end"]       = 20

    t0     = time.time()
    runner = SNRBacktestRunner(**params)
    result = await runner.run()
    secs   = time.time() - t0

    t = result.trades
    if not t:
        return {**cfg, "n_trades": 0, "win_rate": 0, "pf": 0,
                "net_pnl": 0, "mdd": 0, "avg_r": 0, "secs": round(secs, 1)}

    wins        = [x for x in t if x.pnl_usd > 0]
    losses      = [x for x in t if x.pnl_usd <= 0]
    gross_win   = sum(x.pnl_usd for x in wins)
    gross_loss  = abs(sum(x.pnl_usd for x in losses))
    pf          = gross_win / gross_loss if gross_loss > 0 else 999.0
    eq          = np.array(result.equity_curve)
    pk          = np.maximum.accumulate(eq)
    mdd         = float(((eq - pk) / pk * 100).min())
    avg_r       = float(np.mean([x.r_multiple for x in t]))

    return {
        **cfg,
        "n_trades": len(t),
        "win_rate": round(len(wins) / len(t) * 100, 1),
        "pf":       round(pf, 3),
        "net_pnl":  round(result.net_pnl, 2),
        "mdd":      round(mdd, 3),
        "avg_r":    round(avg_r, 3),
        "secs":     round(secs, 1),
    }

# ── 印出排行榜 ────────────────────────────────────────────────────────────────
def print_top(n: int = 20):
    if not RESULT_FILE.exists():
        print("  尚無結果")
        return

    rows = []
    with open(RESULT_FILE, newline="") as f:
        for row in csv.DictReader(f):
            row["pf"]       = float(row["pf"])
            row["n_trades"] = int(row["n_trades"])
            row["net_pnl"]  = float(row["net_pnl"])
            row["mdd"]      = float(row["mdd"])
            row["win_rate"] = float(row["win_rate"])
            rows.append(row)

    # 過濾：至少 50 筆交易才列入排名
    rows = [r for r in rows if r["n_trades"] >= 50]
    rows.sort(key=lambda r: r["pf"], reverse=True)

    print(f"\n  Top {n} 組合（依 PF 排序，交易數 ≥ 50）")
    print(f"  {'FB':>5} {'EMA主':>6} {'EMA次':>6} {'RR':>5} {'量':>5} {'NY':>5}"
          f"  {'交易':>5} {'勝率':>6} {'PF':>6} {'淨利':>9} {'MDD':>7}")
    print("  " + "-" * 80)
    for r in rows[:n]:
        ny = {"ny_only": "NY", "all_day": "全天", "london_ny": "倫敦+NY"}.get(r.get("session", ""), "?")
        print(f"  {float(r['fake_break_depth_mult']):>5.2f}"
              f" {r['htf_primary_ema']:>6}"
              f" {r['htf_secondary_ema']:>6}"
              f" {float(r['min_rr']):>5.1f}"
              f" {float(r['vol_mult']):>5.1f}"
              f" {ny:>5}"
              f"  {r['n_trades']:>5}"
              f" {r['win_rate']:>5.1f}%"
              f" {r['pf']:>6.2f}"
              f" ${r['net_pnl']:>8,.0f}"
              f" {r['mdd']:>6.2f}%")
    print()

# ── 主流程 ────────────────────────────────────────────────────────────────────
async def main(top_only: bool = False, top_n: int = 20):
    if top_only:
        print_top(top_n)
        return

    # 建立全部組合
    keys   = list(GRID.keys())
    combos = [dict(zip(keys, v)) for v in itertools.product(*GRID.values())]
    total  = len(combos)

    # 載入已完成
    done   = load_done()
    remain = [c for c in combos if key_of(c) not in done]

    print(f"\n  SNR v3 全參數窮舉掃描")
    print(f"  總組合: {total}  已完成: {len(done)}  剩餘: {len(remain)}")
    print(f"  結果存至: {RESULT_FILE}")
    print("  " + "=" * 60)

    # 開啟 CSV（append 模式）
    write_header = not RESULT_FILE.exists()
    csv_file = open(RESULT_FILE, "a", newline="")
    writer   = csv.DictWriter(csv_file, fieldnames=CSV_FIELDS)
    if write_header:
        writer.writeheader()

    t_start = time.time()
    interrupted = False
    for idx, cfg in enumerate(remain, start=len(done) + 1):
        label = (f"FB={cfg['fake_break_depth_mult']:.2f} "
                 f"EMA主={cfg['htf_primary_ema']} "
                 f"EMA次={cfg['htf_secondary_ema']} "
                 f"RR={cfg['min_rr']} "
                 f"量={cfg['vol_mult']} "
                 f"{cfg['session']}")

        print(f"  [{idx}/{total}] {label} ...", end=" ", flush=True)

        try:
            row = await run_one(cfg)
            writer.writerow({k: row[k] for k in CSV_FIELDS})
            csv_file.flush()

            elapsed  = time.time() - t_start
            done_now = idx - len(done)
            remain_n = len(remain) - done_now
            eta_secs = (elapsed / done_now * remain_n) if done_now > 0 else 0
            eta_str  = f"{int(eta_secs//3600)}h{int(eta_secs%3600//60)}m"
            pct      = done_now / len(remain) * 100

            print(f"{row['n_trades']:>4}筆 PF={row['pf']:.2f} "
                  f"淨利=${row['net_pnl']:>7,.0f}  "
                  f"[{pct:.1f}%] ETA:{eta_str}")

        except KeyboardInterrupt:
            print("\n  ⚠️  使用者中斷，進度已儲存。下次執行會從這裡繼續。")
            interrupted = True
            break
        except Exception as e:
            print(f"❌ {e}")
            writer.writerow({k: cfg.get(k, "") for k in CSV_FIELDS})
            csv_file.flush()

    csv_file.close()
    if not interrupted:
        print(f"\n  全部完成！共 {total} 組")
    print_top(top_n)

# ── 入口 ──────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--top", type=int, default=0,
                        help="只看排行榜不跑回測（指定顯示幾筆）")
    args = parser.parse_args()

    if args.top:
        print_top(args.top)
    else:
        asyncio.run(main())

"""在專案根目錄執行：python profile_backtest.py"""
import asyncio, cProfile, pstats, io, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from backtest.engine import SNRBacktestRunner

async def run():
    runner = SNRBacktestRunner(sl_max_atr_mult=1.5)
    await runner.run()

def main():
    pr = cProfile.Profile()
    pr.enable()
    asyncio.run(run())
    pr.disable()

    s = io.StringIO()
    ps = pstats.Stats(pr, stream=s).sort_stats('cumulative')
    ps.print_stats(25)
    print(s.getvalue())

if __name__ == "__main__":
    main()

"""
SNR v3 參數掃描 Phase 4
測試移除量能過濾後的效果
"""
import asyncio, sys, os, numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)) + "/..")
from backtest.engine import SNRBacktestRunner

BASE = dict(fake_break_depth_mult=0.40, htf_secondary_ema=9, min_rr=1.5, sl_max_atr_mult=1.5)

SCAN_CONFIGS = [
    {"label": "當前最佳",              **BASE, "vol_mult": 1.5},
    {"label": "無量能過濾",            **BASE, "vol_mult": 0.0},
    {"label": "無量能+FB0.35",         **BASE, "vol_mult": 0.0, "fake_break_depth_mult": 0.35},
    {"label": "無量能+FB0.30",         **BASE, "vol_mult": 0.0, "fake_break_depth_mult": 0.30},
    {"label": "無量能+RR1.2",          **BASE, "vol_mult": 0.0, "min_rr": 1.2},
    {"label": "無量能+FB0.35+RR1.2",   **BASE, "vol_mult": 0.0, "fake_break_depth_mult": 0.35, "min_rr": 1.2},
]

async def run_one(cfg: dict):
    label = cfg.pop("label")
    runner = SNRBacktestRunner(**cfg)
    result = await runner.run()
    t = result.trades
    if not t:
        return {"label": label, "n": 0, "wr": 0, "pf": 0, "nl": 0, "mdd": 0}
    wins   = [x for x in t if x.pnl_usd > 0]
    losses = [x for x in t if x.pnl_usd <= 0]
    pf  = abs(sum(x.pnl_usd for x in wins) / sum(x.pnl_usd for x in losses)) if losses else 999
    eq  = np.array(result.equity_curve)
    pk  = np.maximum.accumulate(eq)
    mdd = float(((eq - pk) / pk * 100).min())
    return {"label": label, "n": len(t), "wr": len(wins)/len(t)*100,
            "pf": pf, "nl": result.net_pnl, "mdd": mdd}

async def main():
    print("\n  SNR v3 參數掃描 Phase 4 — 量能過濾測試")
    print("  " + "=" * 68)
    rows = []
    for cfg in SCAN_CONFIGS:
        label = cfg["label"]
        print(f"  跑: {label} ...", end=" ", flush=True)
        row = await run_one(dict(cfg))
        rows.append(row)
        print(f"完成 ({row['n']} 筆)")

    print(f"\n  {'組合':<24} {'交易數':>6} {'勝率':>7} {'PF':>6} {'淨利':>9} {'MDD':>7}")
    print("  " + "-" * 64)
    for r in rows:
        marker = " ◀" if r["label"] == "當前最佳" else ""
        print(f"  {r['label']:<24} {r['n']:>6} {r['wr']:>6.1f}% {r['pf']:>6.2f} "
              f"${r['nl']:>8,.0f} {r['mdd']:>6.2f}%{marker}")
    print()

if __name__ == "__main__":
    asyncio.run(main())

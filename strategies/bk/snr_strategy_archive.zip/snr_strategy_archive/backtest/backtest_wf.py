"""
SNR v3 Walk-Forward 驗證
三組候選策略，各跑 In-Sample / Out-of-Sample 對比

In-Sample  : 2016-01-01 ~ 2021-12-31（6年，用來確認參數）
Out-of-Sample: 2022-01-01 ~ 2025-12-31（4年，真實驗證）

用法：
    python backtest_wf.py
"""
import asyncio, sys, os, time
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from backtest.engine import SNRBacktestRunner

# ── 三組候選參數 ──────────────────────────────────────────────────────────────
CANDIDATES = [
    {
        "name": "A 高品質",
        "desc": "FB=0.50 EMA200/9 RR1.8 全天 vol=1.5",
        "params": dict(
            fake_break_depth_mult = 0.50,
            htf_primary_ema       = 200,
            htf_secondary_ema     = 9,
            min_rr                = 1.8,
            vol_mult              = 1.5,
            sl_max_atr_mult       = 1.5,
            # 全天
            session_london_start  = 0,
            session_london_end    = 24,
            session_ny_start      = 99,
            session_ny_start_min  = 0,
            session_ny_end        = 99,
        ),
    },
    {
        "name": "B 平衡",
        "desc": "FB=0.20 EMA200/21 RR1.2 NY vol=0",
        "params": dict(
            fake_break_depth_mult = 0.20,
            htf_primary_ema       = 200,
            htf_secondary_ema     = 21,
            min_rr                = 1.2,
            vol_mult              = 0.0,
            sl_max_atr_mult       = 1.5,
            # NY only
            session_london_start  = 99,
            session_london_end    = 99,
            session_ny_start      = 13,
            session_ny_start_min  = 30,
            session_ny_end        = 20,
        ),
    },
    {
        "name": "C 高頻",
        "desc": "FB=0.50 EMA100/9 RR1.8 NY vol=0",
        "params": dict(
            fake_break_depth_mult = 0.50,
            htf_primary_ema       = 100,
            htf_secondary_ema     = 9,
            min_rr                = 1.8,
            vol_mult              = 0.0,
            sl_max_atr_mult       = 1.5,
            # NY only
            session_london_start  = 99,
            session_london_end    = 99,
            session_ny_start      = 13,
            session_ny_start_min  = 30,
            session_ny_end        = 20,
        ),
    },
]

IN_SAMPLE   = ("2016-01-01", "2021-12-31")
OUT_SAMPLE  = ("2022-01-01", "2025-12-31")

# ── 單次回測 ──────────────────────────────────────────────────────────────────
async def run_one(params: dict, date_from: str, date_to: str) -> dict:
    t0 = time.time()
    runner = SNRBacktestRunner(**params, date_from=date_from, date_to=date_to)
    result = await runner.run()
    secs   = time.time() - t0

    t = result.trades
    if not t:
        return {"n": 0, "wr": 0, "pf": 0, "nl": 0, "mdd": 0, "avg_r": 0, "secs": secs}

    wins      = [x for x in t if x.pnl_usd > 0]
    losses    = [x for x in t if x.pnl_usd <= 0]
    gross_win = sum(x.pnl_usd for x in wins)
    gross_los = abs(sum(x.pnl_usd for x in losses))
    pf        = gross_win / gross_los if gross_los > 0 else 999.0
    eq        = np.array(result.equity_curve)
    pk        = np.maximum.accumulate(eq)
    mdd       = float(((eq - pk) / pk * 100).min())
    avg_r     = float(np.mean([x.r_multiple for x in t]))

    return {
        "n":     len(t),
        "wr":    round(len(wins) / len(t) * 100, 1),
        "pf":    round(pf, 2),
        "nl":    round(result.net_pnl, 0),
        "mdd":   round(mdd, 2),
        "avg_r": round(avg_r, 3),
        "secs":  round(secs, 1),
    }

# ── 判斷結果 ──────────────────────────────────────────────────────────────────
def verdict(ins: dict, oos: dict) -> str:
    if ins["n"] < 30 or oos["n"] < 10:
        return "⚠️  樣本太少"
    pf_ratio  = oos["pf"] / ins["pf"] if ins["pf"] > 0 else 0
    mdd_ratio = abs(oos["mdd"]) / abs(ins["mdd"]) if ins["mdd"] != 0 else 999
    if pf_ratio >= 0.80 and oos["pf"] >= 1.5 and mdd_ratio <= 2.0:
        return "✅  穩健"
    elif pf_ratio >= 0.60 and oos["pf"] >= 1.2:
        return "⚠️  輕微衰退"
    else:
        return "❌  過度擬合"

# ── 主流程 ────────────────────────────────────────────────────────────────────
async def main():
    print("\n" + "=" * 65)
    print("  SNR v3 Walk-Forward 驗證")
    print(f"  In-Sample  : {IN_SAMPLE[0]} ~ {IN_SAMPLE[1]}")
    print(f"  Out-of-Sample: {OUT_SAMPLE[0]} ~ {OUT_SAMPLE[1]}")
    print("=" * 65)

    results = []
    for c in CANDIDATES:
        print(f"\n  [{c['name']}] {c['desc']}")

        print(f"    In-Sample  跑中...", end=" ", flush=True)
        ins = await run_one(c["params"], *IN_SAMPLE)
        print(f"{ins['n']}筆 PF={ins['pf']} ({ins['secs']:.0f}s)")

        print(f"    Out-of-Sample 跑中...", end=" ", flush=True)
        oos = await run_one(c["params"], *OUT_SAMPLE)
        print(f"{oos['n']}筆 PF={oos['pf']} ({oos['secs']:.0f}s)")

        results.append((c, ins, oos))

    # ── 結果報告 ──────────────────────────────────────────────────────────────
    print("\n\n" + "=" * 65)
    print("  Walk-Forward 結果對比")
    print("=" * 65)

    for c, ins, oos in results:
        v = verdict(ins, oos)
        pf_drop = ((oos["pf"] - ins["pf"]) / ins["pf"] * 100) if ins["pf"] > 0 else 0
        print(f"\n  ── {c['name']} ({c['desc']}) ──")
        print(f"  {'':20}  {'交易數':>6} {'勝率':>6} {'PF':>6} {'淨利':>9} {'MDD':>7} {'avgR':>6}")
        print(f"  {'In-Sample  (2016-21)':20}  {ins['n']:>6} {ins['wr']:>5.1f}% {ins['pf']:>6.2f} ${ins['nl']:>8,.0f} {ins['mdd']:>6.2f}% {ins['avg_r']:>6.3f}")
        print(f"  {'Out-of-Sample(2022-25)':20}  {oos['n']:>6} {oos['wr']:>5.1f}% {oos['pf']:>6.2f} ${oos['nl']:>8,.0f} {oos['mdd']:>6.2f}% {oos['avg_r']:>6.3f}")
        print(f"  PF 衰退: {pf_drop:+.1f}%   判斷: {v}")

    print("\n" + "=" * 65)
    print("  判斷標準：")
    print("  ✅  穩健     OOS PF ≥ 1.5，且 OOS/IS PF ≥ 80%，MDD 未翻倍")
    print("  ⚠️  輕微衰退  OOS PF ≥ 1.2，OOS/IS PF ≥ 60%")
    print("  ❌  過度擬合  OOS PF < 1.2，或 OOS/IS PF < 60%")
    print("=" * 65 + "\n")

if __name__ == "__main__":
    asyncio.run(main())

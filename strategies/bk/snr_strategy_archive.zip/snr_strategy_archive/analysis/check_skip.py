"""快速跑一次回測，只印 skip 統計"""
import asyncio, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from backtest.engine import SNRBacktestRunner

async def main():
    for name, params, date_range in [
        ("A IS", dict(fake_break_depth_mult=0.50, htf_primary_ema=200, htf_secondary_ema=9,
                      min_rr=1.8, vol_mult=1.5, sl_max_atr_mult=1.5,
                      session_london_start=0, session_london_end=24,
                      session_ny_start=99, session_ny_start_min=0, session_ny_end=99),
         ("2016-01-01", "2021-12-31")),
        ("B IS", dict(fake_break_depth_mult=0.20, htf_primary_ema=200, htf_secondary_ema=21,
                      min_rr=1.2, vol_mult=0.0, sl_max_atr_mult=1.5,
                      session_london_start=99, session_london_end=99,
                      session_ny_start=13, session_ny_start_min=30, session_ny_end=20),
         ("2016-01-01", "2021-12-31")),
    ]:
        runner = SNRBacktestRunner(**params, date_from=date_range[0], date_to=date_range[1])
        result = await runner.run()
        strategy = runner._strategy
        total = sum(strategy.skip_counts.values()) + result.total_trades
        print(f"\n  [{name}] 共 skip {sum(strategy.skip_counts.values())} 次")
        for k, v in strategy.skip_counts.items():
            if v > 0:
                print(f"    {k:<20}: {v:>6} ({v/total*100:.1f}%)")
        print(f"    {'進場成功':<20}: {result.total_trades:>6} ({result.total_trades/total*100:.1f}%)")

asyncio.run(main())

"""
詳細分析三組策略：
1. Skip 統計（哪個條件過濾掉最多）
2. 每年損益分布（找出哪幾年表現差）
3. 多空分布（策略有沒有方向偏差）
4. 持倉時間分布
"""
import asyncio, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import pandas as pd
from backtest.engine import SNRBacktestRunner

CANDIDATES = [
    ("A 高品質", dict(
        fake_break_depth_mult=0.50, htf_primary_ema=200, htf_secondary_ema=9,
        min_rr=1.8, vol_mult=1.5, sl_max_atr_mult=1.5,
        session_london_start=0, session_london_end=24,
        session_ny_start=99, session_ny_start_min=0, session_ny_end=99,
    )),
    ("B 平衡", dict(
        fake_break_depth_mult=0.20, htf_primary_ema=200, htf_secondary_ema=21,
        min_rr=1.2, vol_mult=0.0, sl_max_atr_mult=1.5,
        session_london_start=99, session_london_end=99,
        session_ny_start=13, session_ny_start_min=30, session_ny_end=20,
    )),
    ("C 高頻", dict(
        fake_break_depth_mult=0.50, htf_primary_ema=100, htf_secondary_ema=9,
        min_rr=1.8, vol_mult=0.0, sl_max_atr_mult=1.5,
        session_london_start=99, session_london_end=99,
        session_ny_start=13, session_ny_start_min=30, session_ny_end=20,
    )),
]

async def analyze(name, params):
    runner = SNRBacktestRunner(**params)
    result = await runner.run()
    trades = result.trades
    strategy = runner._strategy

    print(f"\n{'='*60}")
    print(f"  {name}")
    print(f"{'='*60}")

    # 1. Skip 統計
    total_signals = sum(strategy.skip_counts.values()) + len(trades)
    print(f"\n  [進場過濾] 總訊號 {total_signals} 次，進場 {len(trades)} 次 ({len(trades)/total_signals*100:.1f}%)")
    for k, v in sorted(strategy.skip_counts.items(), key=lambda x: -x[1]):
        if v > 0:
            print(f"    {k:<22}: {v:>5} ({v/total_signals*100:.1f}%)")

    # 2. 每年損益
    print(f"\n  [每年表現]")
    by_year = {}
    for t in trades:
        y = t.entry_time.year
        if y not in by_year:
            by_year[y] = []
        by_year[y].append(t)

    print(f"    {'年份':>5} {'筆數':>5} {'勝率':>6} {'淨利':>9} {'avgR':>6}")
    print(f"    " + "-" * 38)
    for y in sorted(by_year):
        ts   = by_year[y]
        wins = [t for t in ts if t.pnl_usd > 0]
        nl   = sum(t.pnl_usd for t in ts)
        avgr = np.mean([t.r_multiple for t in ts])
        wr   = len(wins)/len(ts)*100
        flag = " ← 差" if nl < 0 else (" ← 弱" if wr < 40 else "")
        print(f"    {y:>5} {len(ts):>5} {wr:>5.1f}% ${nl:>7,.0f} {avgr:>6.3f}{flag}")

    # 3. 多空分析
    longs  = [t for t in trades if t.side == 0]
    shorts = [t for t in trades if t.side == 1]
    if longs:
        long_wr  = len([t for t in longs  if t.pnl_usd > 0]) / len(longs)  * 100
        long_nl  = sum(t.pnl_usd for t in longs)
    if shorts:
        short_wr = len([t for t in shorts if t.pnl_usd > 0]) / len(shorts) * 100
        short_nl = sum(t.pnl_usd for t in shorts)

    print(f"\n  [多空分析]")
    print(f"    多頭: {len(longs):>3} 筆  勝率 {long_wr:.1f}%  淨利 ${long_nl:,.0f}")
    print(f"    空頭: {len(shorts):>3} 筆  勝率 {short_wr:.1f}%  淨利 ${short_nl:,.0f}")

    # 4. 出場方式
    exit_types = {}
    for t in trades:
        e = getattr(t, 'exit_reason', 'unknown')
        exit_types[e] = exit_types.get(e, 0) + 1
    print(f"\n  [出場方式]")
    for k, v in sorted(exit_types.items(), key=lambda x: -x[1]):
        print(f"    {k:<20}: {v:>4} ({v/len(trades)*100:.1f}%)")

async def main():
    for name, params in CANDIDATES:
        await analyze(name, params)
    print()

asyncio.run(main())

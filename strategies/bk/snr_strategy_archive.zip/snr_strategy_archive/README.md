# SNR v3 策略存檔
> 存檔日期：2026-03

---

## 專案概述

基於 **SR 區假突破** 的 MNQ 15M 策略，搭配自建回測引擎，
完成從策略開發、參數優化、到 Walk-Forward 驗證的完整流程。

合約：`CON.F.US.MNQ.H26`  
數據：8.9 年 15M K 棒（118,227 根）  
平台：TopstepX 50K 帳號

---

## 策略邏輯

### 核心概念
在 SR 區邊緣發生假突破後，反向進場。

### 進場條件（5 個全過）
1. **時段過濾**：只在設定時段運作（倫敦/紐約/全天）
2. **HTF 趨勢確認**：主次兩個 EMA 方向一致才進場
3. **靠近 SR 區**：價格需在 SR 區附近
4. **假突破訊號**：K 棒刺穿 SR 邊緣後收回，深度 ≤ ATR × `fake_break_depth_mult`
5. **RR 驗證**：對面 SR 當 TP，確認 RR ≥ `min_rr`

### 出場管理
- SL：假突破最低/高點 - buffer
- TP：對面 SR 區邊緣
- 0.8R → 部分止盈（平半倉，SL 移到 BE）
- 1.2R → 啟動 Trailing SL

### SR 識別
- 4 個時框同時看：15M / 1H / 4H / 1D
- 密度法計算 SR 區，每 288 根重算一次
- 跨時框相近的區域自動合併

---

## 三組候選策略

### A 高品質
```
fake_break_depth_mult = 0.50
htf_primary_ema       = 200
htf_secondary_ema     = 9
min_rr                = 1.8
vol_mult              = 1.5
sl_max_atr_mult       = 1.5
session               = all_day
```
| 指標 | IS (2016-21) | OOS (2022-25) |
|------|-------------|--------------|
| 交易數 | 45 | 58 |
| 勝率 | 55.6% | 53.4% |
| PF | 3.84 | 3.58 |
| 淨利 | $1,294 | $3,287 |
| MDD | -0.18% | -0.35% |

特點：MDD 最低，兩段結果最一致，每年約 14 筆。

---

### B 平衡
```
fake_break_depth_mult = 0.20
htf_primary_ema       = 200
htf_secondary_ema     = 21
min_rr                = 1.2
vol_mult              = 0.0
sl_max_atr_mult       = 1.5
session               = ny_only (13:30-20:00)
```
| 指標 | IS (2016-21) | OOS (2022-25) |
|------|-------------|--------------|
| 交易數 | 114 | 87 |
| 勝率 | 43.0% | 54.0% |
| PF | 1.51 | 3.68 |
| 淨利 | $924 | $4,506 |
| MDD | -0.71% | -0.50% |

特點：OOS 表現極佳，但 IS 偏弱（低波動環境下表現差）。

---

### C 高頻
```
fake_break_depth_mult = 0.50
htf_primary_ema       = 100
htf_secondary_ema     = 9
min_rr                = 1.8
vol_mult              = 0.0
sl_max_atr_mult       = 1.5
session               = ny_only (13:30-20:00)
```
| 指標 | IS (2016-21) | OOS (2022-25) |
|------|-------------|--------------|
| 交易數 | 178 | 132 |
| 勝率 | 48.9% | 43.9% |
| PF | 2.02 | 1.87 |
| 淨利 | $2,712 | $3,420 |
| MDD | -0.63% | -1.06% |

特點：頻率最高（每年 33 筆），但多空嚴重不對稱（多頭 WR 57.5% vs 空頭 44%）。

---

## 口數建議（Topstep 50K）

| 策略 | 建議口數 | 通過率 | 失敗率 | 中位月數 | 期望淨賺 |
|------|---------|------|------|---------|---------|
| A | 5 口 | 99.7% | 0.2% | 14.6月 | $2,228 |
| B | 8 口 | 99.4% | 0.6% | 5.2月 | $2,694 |
| C | 4 口 | 99.4% | 0.6% | 8.0月 | $2,524 |

**B 平衡 8 口期望值最高（$2,694）**，考核最快（中位 5.2 個月）。

---

## 回測引擎優化歷程

| 版本 | 速度 | 改動 |
|------|------|------|
| 原始 | 179秒/組 | 基準 |
| HTF precomputed | 150秒 | EMA 預算查表 |
| 跳過 dashboard | 115秒 | 回測模式跳過 UI |
| FastDF | 61秒 | 替換 pandas 欄位存取 |
| numpy 直接存取 | 25秒 | 移除 df.iloc[i] |
| logging 關閉 | 24秒 | 關 debug log |

**最終：24秒/組，約原始速度的 7.5 倍。**

---

## 關鍵技術

### FastDF
輕量 DataFrame 替代品，策略程式碼不需修改，欄位存取直接回傳 numpy slice。
位置：`backtest/engine.py` → `class FastDF`

### HTF Precomputed
回測前預算所有 HTF EMA 方向，存為 sorted arrays，查表 O(log n)。
避免每根 K 棒都重算 EMA。

### 時段過濾修復
回測用 K 棒時間（`df.index[-1]`），即時用系統 UTC 時間。
`_is_session_open(bar_time=None)` 參數控制。

### Walk-Forward 驗證
- In-Sample：2016-2021（6年）
- Out-of-Sample：2022-2025（4年）
- 引擎支援 `date_from` / `date_to` 參數

---

## 待優化方向（未完成）

1. **C 策略只做多**：空頭勝率 44% 遠低於多頭 57.5%，關閉空頭可提升 PF
2. **波動率過濾**：低波動環境（2017/2019/2021）策略表現差，加入 ATR 相對水準過濾
3. **TP 邏輯改善**：目前 TP 命中率只有 17-26%，考慮加 `tp_min_r` 參數跳過太近的 SR
4. **B 策略 IS 期弱**：2019/2021 勝率只有 30-35%，找出低波動市場的過濾條件

---

## 檔案說明

```
backtest/
  backtest_engine.py   回測引擎主體（FastDF、Walk-Forward 日期過濾）
  backtest_grid.py     1296 組參數窮舉掃描（中斷續跑）
  backtest_wf.py       Walk-Forward 驗證腳本（三組同時跑）
  backtest_scan.py     舊版 Phase 掃描腳本
  profile_backtest.py  性能分析腳本

strategy/
  snr_strategy_v3.py   策略主體（HTF precomputed、時段過濾修復）
  snr_strategy.py      v2 舊策略（保留參考）
  bar_store.py         K 棒數據管理

analysis/
  analyze_detail.py    詳細分析（skip 統計、每年表現、多空分析）
  check_skip.py        快速 skip 統計

docs/
  strategy_spec.md     策略規格文件
```

---

## Grid Search 最佳結果（前 5）

| FB | EMA主 | EMA次 | RR | 量 | 時段 | 交易數 | PF | 淨利 |
|----|-------|-------|----|----|------|--------|-----|------|
| 0.50 | 200 | 9 | 1.8 | 1.5 | 全天 | 103 | 3.40 | $4,334 |
| 0.40 | 200 | 9 | 1.5 | 1.5 | 全天 | 103 | 3.34 | $4,185 |
| 0.20 | 200 | 21 | 1.8 | 1.0 | NY | 112 | 3.19 | $4,359 |
| 0.50 | 200 | 21 | 1.5 | 1.5 | NY | 102 | 3.16 | $4,646 |
| 0.20 | 200 | 21 | 1.2 | 1.0 | NY | 141 | 3.11 | $5,254 |
